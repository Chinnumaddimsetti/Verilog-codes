/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Verilog codes/rtl/johnson_counter.v";
static unsigned int ng1[] = {0U, 0U};



static void Always_7_0(char *t0)
{
    char t13[8];
    char t14[8];
    char t16[8];
    char t19[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t15;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;

LAB0:    t1 = (t0 + 2528U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(7, ng0);
    t2 = (t0 + 2848);
    *((int *)t2) = 1;
    t3 = (t0 + 2560);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(7, ng0);

LAB5:    xsi_set_current_line(8, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(10, ng0);

LAB10:    xsi_set_current_line(11, ng0);
    t2 = (t0 + 1608);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t14, 0, 8);
    t5 = (t14 + 4);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 1);
    *((unsigned int *)t14) = t7;
    t8 = *((unsigned int *)t11);
    t9 = (t8 >> 1);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t10 & 7U);
    t15 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t15 & 7U);
    t12 = (t0 + 1608);
    t17 = (t12 + 56U);
    t18 = *((char **)t17);
    memset(t19, 0, 8);
    t20 = (t19 + 4);
    t21 = (t18 + 4);
    t22 = *((unsigned int *)t18);
    t23 = (t22 >> 0);
    t24 = (t23 & 1);
    *((unsigned int *)t19) = t24;
    t25 = *((unsigned int *)t21);
    t26 = (t25 >> 0);
    t27 = (t26 & 1);
    *((unsigned int *)t20) = t27;
    memset(t16, 0, 8);
    t28 = (t19 + 4);
    t29 = *((unsigned int *)t28);
    t30 = (~(t29));
    t31 = *((unsigned int *)t19);
    t32 = (t31 & t30);
    t33 = (t32 & 1U);
    if (t33 != 0)
        goto LAB14;

LAB12:    if (*((unsigned int *)t28) == 0)
        goto LAB11;

LAB13:    t34 = (t16 + 4);
    *((unsigned int *)t16) = 1;
    *((unsigned int *)t34) = 1;

LAB14:    t35 = (t16 + 4);
    t36 = (t19 + 4);
    t37 = *((unsigned int *)t19);
    t38 = (~(t37));
    *((unsigned int *)t16) = t38;
    *((unsigned int *)t35) = 0;
    if (*((unsigned int *)t36) != 0)
        goto LAB16;

LAB15:    t43 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t43 & 1U);
    t44 = *((unsigned int *)t35);
    *((unsigned int *)t35) = (t44 & 1U);
    xsi_vlogtype_concat(t13, 4, 4, 2U, t16, 1, t14, 3);
    t45 = (t0 + 1608);
    xsi_vlogvar_wait_assign_value(t45, t13, 0, 0, 4, 0LL);

LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(8, ng0);

LAB9:    xsi_set_current_line(9, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 1608);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 4, 0LL);
    goto LAB8;

LAB11:    *((unsigned int *)t16) = 1;
    goto LAB14;

LAB16:    t39 = *((unsigned int *)t16);
    t40 = *((unsigned int *)t36);
    *((unsigned int *)t16) = (t39 | t40);
    t41 = *((unsigned int *)t35);
    t42 = *((unsigned int *)t36);
    *((unsigned int *)t35) = (t41 | t42);
    goto LAB15;

}


extern void work_m_00000000003558132878_0821804222_init()
{
	static char *pe[] = {(void *)Always_7_0};
	xsi_register_didat("work_m_00000000003558132878_0821804222", "isim/tb_twisted_ring_counter_isim_beh.exe.sim/work/m_00000000003558132878_0821804222.didat");
	xsi_register_executes(pe);
}
