/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "a=%b,y=%b";
static const char *ng1 = "D:/Verilog codes/tb/dec3_8_tb.v";
static int ng2[] = {1, 0};
static int ng3[] = {0, 0};
static int ng4[] = {2, 0};

void Monitor_10_2(char *);
void Monitor_10_2(char *);


static void Monitor_10_2_Func(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    t1 = (t0 + 1448);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t0 + 1048U);
    t5 = *((char **)t4);
    xsi_vlogfile_write(1, 0, 3, ng0, 3, t0, (char)118, t3, 3, (char)118, t5, 8);

LAB1:    return;
}

static void Initial_5_0(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    int t10;

LAB0:    xsi_set_current_line(6, ng1);

LAB2:    xsi_set_current_line(7, ng1);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 1448);
    t4 = (t0 + 1448);
    t5 = (t4 + 72U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng3)));
    xsi_vlog_generic_convert_bit_index(t3, t6, 2, t7, 32, 1);
    t8 = (t3 + 4);
    t9 = *((unsigned int *)t8);
    t10 = (!(t9));
    if (t10 == 1)
        goto LAB3;

LAB4:    xsi_set_current_line(7, ng1);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 1448);
    t4 = (t0 + 1448);
    t5 = (t4 + 72U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng2)));
    xsi_vlog_generic_convert_bit_index(t3, t6, 2, t7, 32, 1);
    t8 = (t3 + 4);
    t9 = *((unsigned int *)t8);
    t10 = (!(t9));
    if (t10 == 1)
        goto LAB5;

LAB6:    xsi_set_current_line(7, ng1);
    t1 = ((char*)((ng3)));
    t2 = (t0 + 1448);
    t4 = (t0 + 1448);
    t5 = (t4 + 72U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng4)));
    xsi_vlog_generic_convert_bit_index(t3, t6, 2, t7, 32, 1);
    t8 = (t3 + 4);
    t9 = *((unsigned int *)t8);
    t10 = (!(t9));
    if (t10 == 1)
        goto LAB7;

LAB8:
LAB1:    return;
LAB3:    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t3), 1);
    goto LAB4;

LAB5:    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t3), 1);
    goto LAB6;

LAB7:    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t3), 1);
    goto LAB8;

}

static void Initial_9_1(char *t0)
{

LAB0:    xsi_set_current_line(10, ng1);
    Monitor_10_2(t0);

LAB1:    return;
}

static void Initial_11_3(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 2864U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(12, ng1);

LAB4:    xsi_set_current_line(13, ng1);
    t2 = (t0 + 2672);
    xsi_process_wait(t2, 30000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(13, ng1);
    xsi_vlog_finish(1);
    goto LAB1;

}

void Monitor_10_2(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 2920);
    t2 = (t0 + 3432);
    xsi_vlogfile_monitor((void *)Monitor_10_2_Func, t1, t2);

LAB1:    return;
}


extern void work_m_00000000003717449128_3671711236_init()
{
	static char *pe[] = {(void *)Initial_5_0,(void *)Initial_9_1,(void *)Initial_11_3,(void *)Monitor_10_2};
	xsi_register_didat("work_m_00000000003717449128_3671711236", "isim/tb_isim_beh.exe.sim/work/m_00000000003717449128_3671711236.didat");
	xsi_register_executes(pe);
}
