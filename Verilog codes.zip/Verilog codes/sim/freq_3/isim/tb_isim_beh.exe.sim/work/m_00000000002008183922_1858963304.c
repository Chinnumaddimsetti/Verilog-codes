/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Verilog codes/rtl/freq_3.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};



static void Cont_7_0(char *t0)
{
    char t3[8];
    char t6[8];
    char t18[8];
    char t27[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    char *t16;
    char *t17;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    char *t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    char *t62;
    char *t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    char *t72;
    char *t73;
    char *t74;
    char *t75;
    char *t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;
    unsigned int t80;
    unsigned int t81;
    char *t82;
    unsigned int t83;
    unsigned int t84;
    char *t85;

LAB0:    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(7, ng0);
    t2 = (t0 + 2088);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    memset(t6, 0, 8);
    t7 = (t6 + 4);
    t8 = (t5 + 4);
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 0);
    t11 = (t10 & 1);
    *((unsigned int *)t6) = t11;
    t12 = *((unsigned int *)t8);
    t13 = (t12 >> 0);
    t14 = (t13 & 1);
    *((unsigned int *)t7) = t14;
    t15 = (t0 + 2088);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memset(t18, 0, 8);
    t19 = (t18 + 4);
    t20 = (t17 + 4);
    t21 = *((unsigned int *)t17);
    t22 = (t21 >> 1);
    t23 = (t22 & 1);
    *((unsigned int *)t18) = t23;
    t24 = *((unsigned int *)t20);
    t25 = (t24 >> 1);
    t26 = (t25 & 1);
    *((unsigned int *)t19) = t26;
    t28 = *((unsigned int *)t6);
    t29 = *((unsigned int *)t18);
    t30 = (t28 | t29);
    *((unsigned int *)t27) = t30;
    t31 = (t6 + 4);
    t32 = (t18 + 4);
    t33 = (t27 + 4);
    t34 = *((unsigned int *)t31);
    t35 = *((unsigned int *)t32);
    t36 = (t34 | t35);
    *((unsigned int *)t33) = t36;
    t37 = *((unsigned int *)t33);
    t38 = (t37 != 0);
    if (t38 == 1)
        goto LAB4;

LAB5:
LAB6:    memset(t3, 0, 8);
    t55 = (t27 + 4);
    t56 = *((unsigned int *)t55);
    t57 = (~(t56));
    t58 = *((unsigned int *)t27);
    t59 = (t58 & t57);
    t60 = (t59 & 1U);
    if (t60 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t55) == 0)
        goto LAB7;

LAB9:    t61 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t61) = 1;

LAB10:    t62 = (t3 + 4);
    t63 = (t27 + 4);
    t64 = *((unsigned int *)t27);
    t65 = (~(t64));
    *((unsigned int *)t3) = t65;
    *((unsigned int *)t62) = 0;
    if (*((unsigned int *)t63) != 0)
        goto LAB12;

LAB11:    t70 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t70 & 1U);
    t71 = *((unsigned int *)t62);
    *((unsigned int *)t62) = (t71 & 1U);
    t72 = (t0 + 3936);
    t73 = (t72 + 56U);
    t74 = *((char **)t73);
    t75 = (t74 + 56U);
    t76 = *((char **)t75);
    memset(t76, 0, 8);
    t77 = 1U;
    t78 = t77;
    t79 = (t3 + 4);
    t80 = *((unsigned int *)t3);
    t77 = (t77 & t80);
    t81 = *((unsigned int *)t79);
    t78 = (t78 & t81);
    t82 = (t76 + 4);
    t83 = *((unsigned int *)t76);
    *((unsigned int *)t76) = (t83 | t77);
    t84 = *((unsigned int *)t82);
    *((unsigned int *)t82) = (t84 | t78);
    xsi_driver_vfirst_trans(t72, 0, 0);
    t85 = (t0 + 3824);
    *((int *)t85) = 1;

LAB1:    return;
LAB4:    t39 = *((unsigned int *)t27);
    t40 = *((unsigned int *)t33);
    *((unsigned int *)t27) = (t39 | t40);
    t41 = (t6 + 4);
    t42 = (t18 + 4);
    t43 = *((unsigned int *)t41);
    t44 = (~(t43));
    t45 = *((unsigned int *)t6);
    t46 = (t45 & t44);
    t47 = *((unsigned int *)t42);
    t48 = (~(t47));
    t49 = *((unsigned int *)t18);
    t50 = (t49 & t48);
    t51 = (~(t46));
    t52 = (~(t50));
    t53 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t53 & t51);
    t54 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t54 & t52);
    goto LAB6;

LAB7:    *((unsigned int *)t3) = 1;
    goto LAB10;

LAB12:    t66 = *((unsigned int *)t3);
    t67 = *((unsigned int *)t63);
    *((unsigned int *)t3) = (t66 | t67);
    t68 = *((unsigned int *)t62);
    t69 = *((unsigned int *)t63);
    *((unsigned int *)t62) = (t68 | t69);
    goto LAB11;

}

static void Cont_10_1(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    char *t36;

LAB0:    t1 = (t0 + 3256U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(10, ng0);
    t2 = (t0 + 1928);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    memset(t3, 0, 8);
    t6 = (t5 + 4);
    t7 = *((unsigned int *)t6);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB7;

LAB5:    if (*((unsigned int *)t6) == 0)
        goto LAB4;

LAB6:    t12 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t12) = 1;

LAB7:    t13 = (t3 + 4);
    t14 = (t5 + 4);
    t15 = *((unsigned int *)t5);
    t16 = (~(t15));
    *((unsigned int *)t3) = t16;
    *((unsigned int *)t13) = 0;
    if (*((unsigned int *)t14) != 0)
        goto LAB9;

LAB8:    t21 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t21 & 1U);
    t22 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t22 & 1U);
    t23 = (t0 + 4000);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    memset(t27, 0, 8);
    t28 = 1U;
    t29 = t28;
    t30 = (t3 + 4);
    t31 = *((unsigned int *)t3);
    t28 = (t28 & t31);
    t32 = *((unsigned int *)t30);
    t29 = (t29 & t32);
    t33 = (t27 + 4);
    t34 = *((unsigned int *)t27);
    *((unsigned int *)t27) = (t34 | t28);
    t35 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t35 | t29);
    xsi_driver_vfirst_trans(t23, 0, 0);
    t36 = (t0 + 3840);
    *((int *)t36) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t3) = 1;
    goto LAB7;

LAB9:    t17 = *((unsigned int *)t3);
    t18 = *((unsigned int *)t14);
    *((unsigned int *)t3) = (t17 | t18);
    t19 = *((unsigned int *)t13);
    t20 = *((unsigned int *)t14);
    *((unsigned int *)t13) = (t19 | t20);
    goto LAB8;

}

static void Always_12_2(char *t0)
{
    char t13[8];
    char t14[8];
    char t16[8];
    char t34[8];
    char t80[8];
    char t88[8];
    char t120[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t15;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    char *t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    char *t68;
    char *t69;
    char *t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;
    char *t81;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    unsigned int t86;
    int t87;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    char *t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    char *t108;
    char *t109;
    char *t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    char *t119;
    char *t121;
    char *t122;
    char *t123;
    char *t124;
    char *t125;
    unsigned int t126;
    int t127;

LAB0:    t1 = (t0 + 3504U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(12, ng0);
    t2 = (t0 + 3856);
    *((int *)t2) = 1;
    t3 = (t0 + 3536);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(13, ng0);

LAB5:    xsi_set_current_line(14, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(20, ng0);

LAB10:    xsi_set_current_line(22, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t14, 0, 8);
    t5 = (t14 + 4);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 0);
    t8 = (t7 & 1);
    *((unsigned int *)t14) = t8;
    t9 = *((unsigned int *)t11);
    t10 = (t9 >> 0);
    t15 = (t10 & 1);
    *((unsigned int *)t5) = t15;
    t12 = (t0 + 1048U);
    t17 = *((char **)t12);
    memset(t16, 0, 8);
    t12 = (t17 + 4);
    t18 = *((unsigned int *)t12);
    t19 = (~(t18));
    t20 = *((unsigned int *)t17);
    t21 = (t20 & t19);
    t22 = (t21 & 1U);
    if (t22 != 0)
        goto LAB14;

LAB12:    if (*((unsigned int *)t12) == 0)
        goto LAB11;

LAB13:    t23 = (t16 + 4);
    *((unsigned int *)t16) = 1;
    *((unsigned int *)t23) = 1;

LAB14:    t24 = (t16 + 4);
    t25 = (t17 + 4);
    t26 = *((unsigned int *)t17);
    t27 = (~(t26));
    *((unsigned int *)t16) = t27;
    *((unsigned int *)t24) = 0;
    if (*((unsigned int *)t25) != 0)
        goto LAB16;

LAB15:    t32 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t32 & 1U);
    t33 = *((unsigned int *)t24);
    *((unsigned int *)t24) = (t33 & 1U);
    t35 = *((unsigned int *)t14);
    t36 = *((unsigned int *)t16);
    t37 = (t35 | t36);
    *((unsigned int *)t34) = t37;
    t38 = (t14 + 4);
    t39 = (t16 + 4);
    t40 = (t34 + 4);
    t41 = *((unsigned int *)t38);
    t42 = *((unsigned int *)t39);
    t43 = (t41 | t42);
    *((unsigned int *)t40) = t43;
    t44 = *((unsigned int *)t40);
    t45 = (t44 != 0);
    if (t45 == 1)
        goto LAB17;

LAB18:
LAB19:    memset(t13, 0, 8);
    t62 = (t34 + 4);
    t63 = *((unsigned int *)t62);
    t64 = (~(t63));
    t65 = *((unsigned int *)t34);
    t66 = (t65 & t64);
    t67 = (t66 & 1U);
    if (t67 != 0)
        goto LAB23;

LAB21:    if (*((unsigned int *)t62) == 0)
        goto LAB20;

LAB22:    t68 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t68) = 1;

LAB23:    t69 = (t13 + 4);
    t70 = (t34 + 4);
    t71 = *((unsigned int *)t34);
    t72 = (~(t71));
    *((unsigned int *)t13) = t72;
    *((unsigned int *)t69) = 0;
    if (*((unsigned int *)t70) != 0)
        goto LAB25;

LAB24:    t77 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t77 & 1U);
    t78 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t78 & 1U);
    t79 = (t0 + 2088);
    t81 = (t0 + 2088);
    t82 = (t81 + 72U);
    t83 = *((char **)t82);
    t84 = ((char*)((ng1)));
    xsi_vlog_generic_convert_bit_index(t80, t83, 2, t84, 32, 1);
    t85 = (t80 + 4);
    t86 = *((unsigned int *)t85);
    t87 = (!(t86));
    if (t87 == 1)
        goto LAB26;

LAB27:    xsi_set_current_line(23, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t14, 0, 8);
    t5 = (t14 + 4);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 1);
    t8 = (t7 & 1);
    *((unsigned int *)t14) = t8;
    t9 = *((unsigned int *)t11);
    t10 = (t9 >> 1);
    t15 = (t10 & 1);
    *((unsigned int *)t5) = t15;
    t12 = (t0 + 2088);
    t17 = (t12 + 56U);
    t23 = *((char **)t17);
    memset(t16, 0, 8);
    t24 = (t16 + 4);
    t25 = (t23 + 4);
    t18 = *((unsigned int *)t23);
    t19 = (t18 >> 0);
    t20 = (t19 & 1);
    *((unsigned int *)t16) = t20;
    t21 = *((unsigned int *)t25);
    t22 = (t21 >> 0);
    t26 = (t22 & 1);
    *((unsigned int *)t24) = t26;
    t27 = *((unsigned int *)t14);
    t28 = *((unsigned int *)t16);
    t29 = (t27 | t28);
    *((unsigned int *)t34) = t29;
    t38 = (t14 + 4);
    t39 = (t16 + 4);
    t40 = (t34 + 4);
    t30 = *((unsigned int *)t38);
    t31 = *((unsigned int *)t39);
    t32 = (t30 | t31);
    *((unsigned int *)t40) = t32;
    t33 = *((unsigned int *)t40);
    t35 = (t33 != 0);
    if (t35 == 1)
        goto LAB28;

LAB29:
LAB30:    t62 = (t0 + 1048U);
    t68 = *((char **)t62);
    memset(t80, 0, 8);
    t62 = (t68 + 4);
    t54 = *((unsigned int *)t62);
    t55 = (~(t54));
    t56 = *((unsigned int *)t68);
    t58 = (t56 & t55);
    t59 = (t58 & 1U);
    if (t59 != 0)
        goto LAB34;

LAB32:    if (*((unsigned int *)t62) == 0)
        goto LAB31;

LAB33:    t69 = (t80 + 4);
    *((unsigned int *)t80) = 1;
    *((unsigned int *)t69) = 1;

LAB34:    t70 = (t80 + 4);
    t79 = (t68 + 4);
    t60 = *((unsigned int *)t68);
    t61 = (~(t60));
    *((unsigned int *)t80) = t61;
    *((unsigned int *)t70) = 0;
    if (*((unsigned int *)t79) != 0)
        goto LAB36;

LAB35:    t67 = *((unsigned int *)t80);
    *((unsigned int *)t80) = (t67 & 1U);
    t71 = *((unsigned int *)t70);
    *((unsigned int *)t70) = (t71 & 1U);
    t72 = *((unsigned int *)t34);
    t73 = *((unsigned int *)t80);
    t74 = (t72 | t73);
    *((unsigned int *)t88) = t74;
    t81 = (t34 + 4);
    t82 = (t80 + 4);
    t83 = (t88 + 4);
    t75 = *((unsigned int *)t81);
    t76 = *((unsigned int *)t82);
    t77 = (t75 | t76);
    *((unsigned int *)t83) = t77;
    t78 = *((unsigned int *)t83);
    t86 = (t78 != 0);
    if (t86 == 1)
        goto LAB37;

LAB38:
LAB39:    memset(t13, 0, 8);
    t102 = (t88 + 4);
    t103 = *((unsigned int *)t102);
    t104 = (~(t103));
    t105 = *((unsigned int *)t88);
    t106 = (t105 & t104);
    t107 = (t106 & 1U);
    if (t107 != 0)
        goto LAB43;

LAB41:    if (*((unsigned int *)t102) == 0)
        goto LAB40;

LAB42:    t108 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t108) = 1;

LAB43:    t109 = (t13 + 4);
    t110 = (t88 + 4);
    t111 = *((unsigned int *)t88);
    t112 = (~(t111));
    *((unsigned int *)t13) = t112;
    *((unsigned int *)t109) = 0;
    if (*((unsigned int *)t110) != 0)
        goto LAB45;

LAB44:    t117 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t117 & 1U);
    t118 = *((unsigned int *)t109);
    *((unsigned int *)t109) = (t118 & 1U);
    t119 = (t0 + 2088);
    t121 = (t0 + 2088);
    t122 = (t121 + 72U);
    t123 = *((char **)t122);
    t124 = ((char*)((ng2)));
    xsi_vlog_generic_convert_bit_index(t120, t123, 2, t124, 32, 1);
    t125 = (t120 + 4);
    t126 = *((unsigned int *)t125);
    t127 = (!(t126));
    if (t127 == 1)
        goto LAB46;

LAB47:    xsi_set_current_line(26, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB48;

LAB49:
LAB50:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(15, ng0);

LAB9:    xsi_set_current_line(16, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 2088);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 2, 0LL);
    xsi_set_current_line(17, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1928);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB8;

LAB11:    *((unsigned int *)t16) = 1;
    goto LAB14;

LAB16:    t28 = *((unsigned int *)t16);
    t29 = *((unsigned int *)t25);
    *((unsigned int *)t16) = (t28 | t29);
    t30 = *((unsigned int *)t24);
    t31 = *((unsigned int *)t25);
    *((unsigned int *)t24) = (t30 | t31);
    goto LAB15;

LAB17:    t46 = *((unsigned int *)t34);
    t47 = *((unsigned int *)t40);
    *((unsigned int *)t34) = (t46 | t47);
    t48 = (t14 + 4);
    t49 = (t16 + 4);
    t50 = *((unsigned int *)t48);
    t51 = (~(t50));
    t52 = *((unsigned int *)t14);
    t53 = (t52 & t51);
    t54 = *((unsigned int *)t49);
    t55 = (~(t54));
    t56 = *((unsigned int *)t16);
    t57 = (t56 & t55);
    t58 = (~(t53));
    t59 = (~(t57));
    t60 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t60 & t58);
    t61 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t61 & t59);
    goto LAB19;

LAB20:    *((unsigned int *)t13) = 1;
    goto LAB23;

LAB25:    t73 = *((unsigned int *)t13);
    t74 = *((unsigned int *)t70);
    *((unsigned int *)t13) = (t73 | t74);
    t75 = *((unsigned int *)t69);
    t76 = *((unsigned int *)t70);
    *((unsigned int *)t69) = (t75 | t76);
    goto LAB24;

LAB26:    xsi_vlogvar_wait_assign_value(t79, t13, 0, *((unsigned int *)t80), 1, 0LL);
    goto LAB27;

LAB28:    t36 = *((unsigned int *)t34);
    t37 = *((unsigned int *)t40);
    *((unsigned int *)t34) = (t36 | t37);
    t48 = (t14 + 4);
    t49 = (t16 + 4);
    t41 = *((unsigned int *)t48);
    t42 = (~(t41));
    t43 = *((unsigned int *)t14);
    t53 = (t43 & t42);
    t44 = *((unsigned int *)t49);
    t45 = (~(t44));
    t46 = *((unsigned int *)t16);
    t57 = (t46 & t45);
    t47 = (~(t53));
    t50 = (~(t57));
    t51 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t51 & t47);
    t52 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t52 & t50);
    goto LAB30;

LAB31:    *((unsigned int *)t80) = 1;
    goto LAB34;

LAB36:    t63 = *((unsigned int *)t80);
    t64 = *((unsigned int *)t79);
    *((unsigned int *)t80) = (t63 | t64);
    t65 = *((unsigned int *)t70);
    t66 = *((unsigned int *)t79);
    *((unsigned int *)t70) = (t65 | t66);
    goto LAB35;

LAB37:    t89 = *((unsigned int *)t88);
    t90 = *((unsigned int *)t83);
    *((unsigned int *)t88) = (t89 | t90);
    t84 = (t34 + 4);
    t85 = (t80 + 4);
    t91 = *((unsigned int *)t84);
    t92 = (~(t91));
    t93 = *((unsigned int *)t34);
    t87 = (t93 & t92);
    t94 = *((unsigned int *)t85);
    t95 = (~(t94));
    t96 = *((unsigned int *)t80);
    t97 = (t96 & t95);
    t98 = (~(t87));
    t99 = (~(t97));
    t100 = *((unsigned int *)t83);
    *((unsigned int *)t83) = (t100 & t98);
    t101 = *((unsigned int *)t83);
    *((unsigned int *)t83) = (t101 & t99);
    goto LAB39;

LAB40:    *((unsigned int *)t13) = 1;
    goto LAB43;

LAB45:    t113 = *((unsigned int *)t13);
    t114 = *((unsigned int *)t110);
    *((unsigned int *)t13) = (t113 | t114);
    t115 = *((unsigned int *)t109);
    t116 = *((unsigned int *)t110);
    *((unsigned int *)t109) = (t115 | t116);
    goto LAB44;

LAB46:    xsi_vlogvar_wait_assign_value(t119, t13, 0, *((unsigned int *)t120), 1, 0LL);
    goto LAB47;

LAB48:    xsi_set_current_line(27, ng0);

LAB51:    xsi_set_current_line(28, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 2088);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 2, 0LL);
    xsi_set_current_line(29, ng0);
    t2 = (t0 + 1528U);
    t3 = *((char **)t2);
    t2 = (t0 + 1928);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 0LL);
    goto LAB50;

}


extern void work_m_00000000002008183922_1858963304_init()
{
	static char *pe[] = {(void *)Cont_7_0,(void *)Cont_10_1,(void *)Always_12_2};
	xsi_register_didat("work_m_00000000002008183922_1858963304", "isim/tb_isim_beh.exe.sim/work/m_00000000002008183922_1858963304.didat");
	xsi_register_executes(pe);
}
